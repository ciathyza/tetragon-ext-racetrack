<?php
$locale_ids = array("en", "de", "fr", "it");
$locale_names = array("English", "Deutsch", "Fran&ccedil;ais", "Italiano");
if (!empty($_GET["locale"])) $locale_selected = $_GET["locale"];
else $locale_selected = "en";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
	    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	    <meta http-equiv="imagetoolbar" content="no"/>
	    <meta name="author" content="Nothing"/>
	    <meta name="publisher" content="Nothing"/>
		<meta name="copyright" content="Hexagon Star Softworks"/>
	    <meta name="rating" content="general"/>
	    <meta name="distribution" content="global"/>
	    <meta name="robots" content="index, follow, noodp"/>
	    <meta name="revisit" content="5 days"/>
		<meta name="description" lang="en" content="Tetragon Demo for the Racetrack Extension."/>
	    <meta name="content-language" content="en"/>
		<meta name="keywords" content="tetragon, game, engine, racetrack, racing, pseudo3d"/>
		<meta name="google" content="notranslate"/>
		
	    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	    <link type="text/css" href="css/style.css" charset="iso-8859-1" rel="stylesheet" rev="stylesheet" media="screen">
		
		<script type="text/javascript" src="js/swfobject.js"></script>
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery.cookie.js"></script>
		<script type="text/javascript" src="js/tetragon.js"></script>
		
		<script type="text/javascript">
			var flashvars =
			{
				skipPreloader: "false",
				ignoreIniFile: "false",
				ignoreLocaleFile: "false",
				useAbsoluteFilePath: "false",
				loggingVerbose: "false",
				basePath: "",
				locale: ""
			};
			var params =
			{
				allowScriptAccess: "sameDomain",
				allowFullScreen: "true",
				allowFullscreenInteractive: "true",
				wmode: "direct",
				quality: "high",
				bgcolor: "000000"
			};
			var attributes =
			{
				id: "com.hexagonstar.racetrack",
				name: "racetrack",
				align: "middle"
			};
			function getFlashObject()
			{
				return document['com.hexagonstar.racetrack'];
			}
			swfobject.embedSWF("racetrack.swf", "flashContent", "1024", "460", "11.9", false, flashvars, params, attributes, onFlashContentEmbedded);
        </script>
        
		<title>Tetragon Racetrack Demo</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="content">
				<h1>Tetragon Racetrack Demo</h1>
				<div id="header">
					<?php
					if (count($locale_ids) > 1)
					{
						echo '<div id="locale">';
						for ($i = 0; $i < count($locale_ids); ++$i)
						{
							$id = $locale_ids[$i];
							$name = $locale_names[$i];
							$active = ($id == $locale_selected) ? ' active' : '';
							echo '<a href="index.php?locale=' . $id . '" title="' . $id . '" class="' . $id . $active .'">' . $name . '</a>';
						}
						echo '</div>';
					}
					?>
				</div>
				<div id="middle">
					<div id="swfarea">
						<div id="flashContent">
							<div class="meta-header" id="noflash-message">
								<div class="en">
									<p>This website requires Flash Player 11.9. To download Flash Player <a href="http://www.adobe.com/go/getflashplayer" target="_blank">click here</a>. Please note that JavaScript must be active in your browser.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="swf_footer"></div>
				<div id="footer-info-container">
					<div id="footer-info-swf">
						<div id="swf-loading-info">
							<p class="hidden">
								<strong><span class="first">Version </span></strong>
								<span class="line"><span id="version">1.x.x</span> - Build #<span id="buildnr">1</span> (<span id="builddate">14-June-2012</span>)</span>
								<span class="line"><strong>Debug Build:</strong> <span id="isdebugbuild">false</span></span>
								<span class="line"><strong><span id="consolekey">F8</span>:</strong> Toggle Console</span>
								<span class="last"><strong><span id="statskey">CTRL+F8</span>:</strong> Toggle Stats</span>
							</p>
						</div>
					</div>
					<div id="footer-info-browser">
						<span id="flash_info" class="first line"></span>
						<span id="useragent_info" class="last"></span>
					</div>
				</div>
				<div id="logo">
					<a href="http://www.tetragonengine.com/" target="_blank"><img src="img/logo.png" alt="Hexagon Star Softworks"></a>
				</div>
			</div>
		</div>
	</body>
</html>
